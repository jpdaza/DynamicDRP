function q = perm3d(pore, dx);
%
% function q = perm3d(pore, dx);
%
% LB 2D Flow Simulation program
%  pore : 3D binary pore structure (0: pore, 1: grains)
%  dx   : grid spacing in mm scale
%  q    : local velocity field (qx, qy, qz)
%
% Youngseuk Keehm, Mar. 2004, All rights reserved.

[nx,ny,nz] = size(pore);
if(nz < 2) 
    disp('Pore structure should be 3D');
    q = 0;
    return
end

fid = fopen('_lb3d_.pam','w');

fprintf(fid,'_lb3d_.dat \n');
fprintf(fid,'0 \n');
fprintf(fid,'%d %d %d \n', nx, ny, nz);
fprintf(fid,'%e \n',dx);
fprintf(fid,'1 \n');
fprintf(fid,'15 \n');
fprintf(fid,'!!! DO NOT CHANGE BELOW !!!! DEBUG PURPOSE !!!\n');
fprintf(fid,'20 \n');
fprintf(fid,'0 \n');
fprintf(fid,'1e-4 \n');
fprintf(fid,'0 \n');

fclose(fid);

fid = fopen('_lb3d_.dat','w');
fprintf(fid,'%d \n', pore(:));
fclose (fid);

! lb3d _lb3d_.pam

q = zeros(nx,ny,nz,3);

flx = load('_lb3d_.dat.flx');

tmp = -pore;
index = 0;
for i=1:nx
   for j=1:ny
      for k=1:nz
         if(pore(i,j,k)==0)
            index=index+1;
            q(i,j,k,1)=flx(index, 1);
            q(i,j,k,2)=flx(index, 2);
            q(i,j,k,3)=flx(index, 3);
         end
      end
   end
end

!del _lb3d_* > null