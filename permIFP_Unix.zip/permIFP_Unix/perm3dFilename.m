function perm = perm3dFilename(pore, dx, name)
%
% function q = perm3d(pore, dx);
%
% LB 2D Flow Simulation program
%  pore : 3D binary pore structure (0: pore, 1: grains)
%  dx   : grid spacing in mm scale
%  q    : local velocity field (qx, qy, qz)
%
% Youngseuk Keehm, Mar. 2004, All rights reserved.

[nx,ny,nz] = size(pore);
if(nz < 2) 
    disp('Pore structure should be 3D');
    q = 0;
    return
end

fid = fopen(['_lb3d_',name,'.pam'],'w');

fprintf(fid,['_lb3d_',name,'.dat \n']);
fprintf(fid,'0 \n');
fprintf(fid,'%d %d %d \n', nx, ny, nz);
fprintf(fid,'%e \n',dx);
fprintf(fid,'0 \n');
fprintf(fid,'15 \n');

fclose(fid);

fid = fopen(['_lb3d_',name,'.dat'],'w');
fprintf(fid,'%d \n', pore(:));
fclose (fid);

eval(['! ./perm_SP_IFP _lb3d_',name,'.pam'])
eval(['!tail -n 3 _lb3d_',name,'.dat.res | head -n 1 | sed ''s/% Cal. Perm(mD)  : //g'' > _lb3d_',name,'.res'])
perm=load(['_lb3d_',name,'.res']);


eval(['!rm _lb3d_',name,'.*'])



